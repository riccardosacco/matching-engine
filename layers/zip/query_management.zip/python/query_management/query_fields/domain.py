def generate_domain(filter_domain):
    return {"term":{"domain": filter_domain}}