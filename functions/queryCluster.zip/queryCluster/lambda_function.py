import json
import package.requests as requests


def lambda_handler(event, context):
    res = requests.post(
        "https://search-matching-engine-nhygzot7nqafdvrzb3niwryuay.eu-central-1.es.amazonaws.com/nested_test/_search", {})

    return {
        "statusCode": 200,
        "body": json.dumps({
            "event": event,
            "response": res.text
        })
    }
